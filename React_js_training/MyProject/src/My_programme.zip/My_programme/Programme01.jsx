import React from 'react'

export default function Programme01() {
  return (
    <div>
      <h1>Good Morning</h1>
    </div>
  )
}




// import React from 'react'


// export default function Programme01() {
//   return (
//     <div>
//         <h1>good morning</h1>
//     </div>
//   )
// }
