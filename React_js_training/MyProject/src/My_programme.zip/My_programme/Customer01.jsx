import React from 'react'

export default function Customer01() {
  return (
    <div>Customer01</div>
  )
}
