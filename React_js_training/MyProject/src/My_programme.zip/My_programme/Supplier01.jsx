import React from 'react'

export default function Supplier01() {
  return (
    <div>Supplier01</div>
  )
}
