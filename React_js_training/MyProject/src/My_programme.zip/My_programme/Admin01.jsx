import React from 'react'

export default function Admin01() {
  return (
    <div>Admin01</div>
  )
}
