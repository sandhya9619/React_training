import React from 'react'

export default function Dashbordpage() {
  return (
    <div>
        <h1>Profile........</h1>

        
    </div>
  )
}
