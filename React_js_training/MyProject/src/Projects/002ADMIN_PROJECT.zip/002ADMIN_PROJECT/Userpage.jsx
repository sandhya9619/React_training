import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

export default function Userpage() {
    const [ name,setName]=useState();
    const[email,setEmail]=useState();
    const[password,setPassword]=useState();

    const navigate=useNavigate();

    const handlesubmit =()=>{
        // navigate("/login")
    }

  return (
    <div>
        <form action="" onSubmit={handlesubmit}>
            <input type="text" placeholder='Enter Name' onChange={(e)=>setName(e.target.value)} />
            <input type="text" placeholder='Enter Email' onChange={(e)=>setEmail(e.target.value)} />
            <input type="text" placeholder='Enter Password' onChange={(e)=>setPassword(e.target.value)} />
            <button>Submit</button>
        </form>
        <br />
        <button onClick={()=>{navigate("/login")}}>Login</button>
    </div>
  )
}
