import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

export default function Loginpage() {
    const[email,setEmail]=useState();
    const[password,setPassword]=useState();

    const navigate = useNavigate();

    const handlesubmit=()=>{
        navigate("/dashboard");
    }
  return (
    <div>
        <h1>login page......</h1>
        <form action="" onSubmit={handlesubmit}>
            <input type="text" placeholder='Enter your Email' onChange={(e)=>setEmail(e.target.value)} />
            <input type="text" placeholder='Enter your Password' onChange={(e)=>setPassword(e.target.value)} />
            <button>Submot</button>
        </form>

    </div>
  )
}
