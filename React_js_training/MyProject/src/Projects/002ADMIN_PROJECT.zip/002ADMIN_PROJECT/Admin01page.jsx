import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function Admin01page() {
 const navigate = useNavigate();

    const handleadmin=()=>{
        navigate("/admin");
    }
    const handleuser=()=>{
        navigate("/user")
    }
  return (
    <div>
        <div>
            <button onClick={handleadmin}>ADMIN</button>
            <button onClick={handleuser}>USER</button>
        </div>
    </div>
  )
}
