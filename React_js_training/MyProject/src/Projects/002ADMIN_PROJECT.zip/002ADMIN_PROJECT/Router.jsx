import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Admin01page from './Admin01page'
import Admin02page from './Admin02page'
import Existingpage from './Existingpage'
import Userpage from './Userpage'
import { Dashboard } from '@mui/icons-material'
import Loginpage from './Loginpage'
import Dashbordpage from './Dashbordpage'

export default function Router() {
  return (
    <div>
        <BrowserRouter>
        <Routes>
            <Route path='/' element={<Admin01page/>}></Route>
            <Route path='/admin' element={<Admin02page/>}></Route>
            <Route path='/exist' element={<Existingpage/>}></Route>
            <Route path='/user' element={<Userpage/>}></Route>
            <Route path='/dashboard' element={<Dashbordpage/>}></Route>
            <Route path='/login' element={<Loginpage/>}></Route>
        </Routes>
        </BrowserRouter>
    </div>
  )
}
