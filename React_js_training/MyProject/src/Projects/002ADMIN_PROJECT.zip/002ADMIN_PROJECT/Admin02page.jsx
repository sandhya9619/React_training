import { Box, Button, TextField } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { TextFields } from '@mui/icons-material';

import "./Adminproject.css"

export default function Admin02page() {
    const [email, setEmail] = useState();
    const [password, setpassword] = useState();
    // let img = "05image.jpg"
    const navigate = useNavigate();

    const handlsubmit = () => {
        console.log("clickedddddd");
        navigate("/dashboard")
    }
    useEffect(()=>{
        document.body.style.backgroundImage = "url()",
        document.body.style.backgroundRepeat = "no-repeat"
        // document.body.style.backgroundImage.width = "100%"
        document.body.style.width = "100%"
        // document.body.style.backgroundImage.height = "100px"
        
    })

    return (
        <div className='background' style={{border:"1px solid black",textAlign:"center",height:"510px",paddingTop:"50px"}}>

            <Box sx={{ '& .MuiTextField-root': { m: 1, width: '300px', color: "white",mt:"10px"} }}>
                <h1>Admin Registration </h1>
                <TextField id="outlined-Email-input" label="email" type="email" autoComplete="current-email" />
                <br />
                <TextField id="outlined-password-input" label="Password" type="password" autoComplete="current-password" />
                <br />
                <Button onClick={handlsubmit} variant="contained" disableElevation> Submit </Button>
            </Box>
        </div>
    )
}
