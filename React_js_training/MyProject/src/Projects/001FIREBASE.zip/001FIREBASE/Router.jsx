import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Registrationpage from './Registrationpage'
import Loginpage from './Loginpage'
import Dashboard from './Dashboard'

export default function Router() {
  return (
    <div>
        <BrowserRouter>
        <Routes>
            <Route path='/' element={<Registrationpage/>}></Route>
            <Route path='/login' element={<Loginpage/>}></Route>
            <Route path='/dashboard' element={<Dashboard/>}></Route>
        </Routes>
        </BrowserRouter>
    </div>
  )
}
