import React, { useEffect, useState } from 'react'
import { auth, db, storage } from '../../firebaseConfig';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import {  useNavigate } from 'react-router-dom';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { Upload } from '@mui/icons-material';

export default function Dashboard() {
    const[userDetails,setUserDetails] =useState(null);
    const [profileurl,setProfileUrl]=useState();
    const[uploadingstatus,setUploadingStatus] =useState(false);


    const Navigate = useNavigate();

    useEffect(()=>{
        const subscirbe = onAuthStateChanged(auth,(user)=>{
            if (user) {
                
                fetchCurrentUserDetails();
            }
        })
    }, []);

    const fetchCurrentUserDetails=async(user)=>{
        // const user = auth.currentUser;
        if (user) {
            const userData = await getDoc(doc(db,"student", user.uid));
            // const userData = await getDoc(doc(db,"student", user.uid ));
            console.log(`Welcome Dashboard ${userData.data().name}`);
            setUserDetails(userData.data())
        }
    }

    const handleLogout= async ()=>{
        await signOut(auth);
        Navigate("/login", {replace:true})
    }

    const handlesubmit=async(e)=>{
        e.preventDefault();
        console.log("----> profileurl",profileurl);
        setUploadingStatus(true);

        const user = auth.currentUser;

        if(user){
            const storageRef =  ref(storage,`profilepicture/${user.uid}`);
            await uploadBytes(storageRef,profileurl);

            const downloadUrl = await getDownloadURL(storageRef);

            console.log("----->downloadurl", downloadUrl);

            await updateDoc(doc(db,"student", user.uid),{
                "profilepic" : downloadUrl
            });

        }

        setUploadingStatus(false);


    }
  return (
    <div>
        {userDetails ? <h1>Welcome {userDetails.name} email : {userDetails.email} </h1> : <h1>loading...</h1>}
        <form action="" onSubmit={(e)=>handlesubmit(e)}>
            <label > Upload your image</label>
            <input type="file" onChange={(e)=>setProfileUrl(e.target.files[0])} />
            <input type="submit" value='upload' />
        </form>
        <button onClick={handleLogout}>Logout</button>
    </div>
  )
}
